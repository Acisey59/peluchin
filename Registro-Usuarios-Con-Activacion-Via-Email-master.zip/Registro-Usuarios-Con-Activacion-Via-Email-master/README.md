# Registro-Usuarios-Con-Activacion-Via-Email
Ejemplo de un registro de una pagina web, donde el usuario debe validar su cuenta mediante un link enviado a su correo electronico
<br><h4>Puedes ver y utilizar el ejemplo <a href="http://demos.netosolis.com/confirmacion/">AQUÍ</a></h4>
