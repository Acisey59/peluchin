<?php
class Usuario_NetoSolis extends ActiveRecord\Model
{
	public static $table_name = 'usuario_netosolis';
	public static $primary_key = 'id';
}
?>